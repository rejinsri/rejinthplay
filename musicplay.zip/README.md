# LK-61 Laptop Keyboard

A Casio-style electronic keyboard workstation that runs in the browser. It turns a laptop keyboard (and mouse/touch) into a playable instrument with 12 synthesized voices, a playable drum kit, 5 drum kits, a 13-style rhythm machine with intro / variation A-B / fill-in / ending, auto-accompaniment with sync start, effects, performance recording with MIDI export, and WAV audio capture.

Built with the Web Audio API and plain JavaScript (ES modules, JSDoc). There is no build step and there are no dependencies — the site is static files.

> **Sound honesty:** all built-in instruments are *synthesized* approximations (labelled **SYNTH**). No Casio or other proprietary samples are included or imitated.

---

## How it runs

The server only hands out static files (`index.html` and `src/`). Every laptop that opens the URL runs the whole synthesizer in its own browser and plays through **its own speakers or headphones** — the server never makes sound, needs no sound card, and has no load per player. Any number of laptops can play at once; each one is independent (no shared session).

```
 laptop 1 ─┐                                       ┌─ synth runs here → laptop 1 speakers
 laptop 2 ─┼─ http://tngis.tnega.local:4008 ─ nginx┤  (static files only)
 laptop N ─┘   (192.168.4.252)                     └─ synth runs here → laptop N speakers
```

---

## Deploying to a Linux server

Target: `192.168.4.252`, port `4008`, URL **http://tngis.tnega.local:4008**.

### 1. Copy the files to the server (from Windows)

```powershell
cd D:\general\casio
scp -r index.html src deploy youruser@192.168.4.252:~/lk61
```

### 2. Install nginx and the site (on the server)

```bash
# Ubuntu/Debian:   sudo apt install -y nginx
# RHEL/Rocky/Alma: sudo dnf install -y nginx

sudo mkdir -p /var/www/lk61
sudo cp -r ~/lk61/index.html ~/lk61/src /var/www/lk61/
sudo chmod -R a+rX /var/www/lk61
sudo cp ~/lk61/deploy/lk61.conf /etc/nginx/conf.d/lk61.conf

sudo nginx -t && sudo systemctl enable --now nginx && sudo systemctl reload nginx
```

[`deploy/lk61.conf`](deploy/lk61.conf) listens on 4008, serves `/var/www/lk61`, and sends the same Content-Security-Policy the page declares.

### 3. Open port 4008

```bash
# Ubuntu (ufw)
sudo ufw allow 4008/tcp

# RHEL/Rocky (firewalld + SELinux)
sudo firewall-cmd --permanent --add-port=4008/tcp && sudo firewall-cmd --reload
sudo semanage port -a -t http_port_t -p tcp 4008
sudo restorecon -R /var/www/lk61
```

Check on the server — both should return `200`, and the second `Content-Type: application/javascript`:

```bash
curl -I http://localhost:4008/
curl -I http://localhost:4008/src/ui/app.js
```

### 4. Point the name at the server

- **Recommended:** an internal DNS **A record** `tngis.tnega.local → 192.168.4.252`.
- **Per laptop (Windows):** as Administrator, add to `C:\Windows\System32\drivers\etc\hosts`:
  ```
  192.168.4.252   tngis.tnega.local
  ```

macOS/Linux clients resolve `*.local` through mDNS first, which can be slow or fail; use the DNS record for them.

### 5. Play

Open **`http://tngis.tnega.local:4008`** in Chrome, Edge or Firefox (type the `http://` — some browsers try `https://` first). Click or press any key once to enable sound; browsers block audio until the first interaction.

### Updating

Copy the new files and replace `src/` (so deleted files don't linger), then reload the page on each laptop:

```bash
sudo rm -rf /var/www/lk61/src
sudo cp -r ~/lk61/index.html ~/lk61/src /var/www/lk61/
sudo chmod -R a+rX /var/www/lk61
```

The site sends `Cache-Control: no-cache`, so a normal reload picks up the new version.

### Running locally

Any static file server works, e.g. `python -m http.server 4008` in this folder, then open `http://localhost:4008`. Opening `index.html` directly from disk (`file://`) does **not** work — browsers block ES modules there.

---

## Playing

| Keys | Action |
| --- | --- |
| `A W S E D F T G Y H U J K O L P ; '` | Notes C → F (white keys on the home row, black keys above) |
| `Z` / `X` | Octave down / up (−3 … +3) |
| `←` / `→` | Transpose −/+ 1 semitone (±12) |
| `↑` / `↓` (hold) | Pitch bend up / down 2 semitones |
| `Space` | Sustain pedal (hold, or toggle — see Settings) |
| `Shift` + note | Accented (louder) note |
| `C` / `V` | Velocity −/+ 8 |
| `1`–`9`, `0` | Select instrument 1–10 (`9` = Drum Kit) |
| `Enter` | Rhythm start / stop |
| `-` / `=` | Tempo −/+ 1 BPM |
| `[` / `]` | Master volume |
| `F1` help · `F2` accompaniment · `F3` record · `F4` play · `F6` metronome | |
| `F5` sync start · `F7` intro · `F8` / `F9` variation A / B · `F10` fill-in · `F11` ending | Arranger (hold `Fn` on many laptops) |
| `Esc` | All notes off (panic) / close dialog |

The page takes over the function keys it uses (so `F5` does not reload). If a browser still keeps one for itself — for example `F11` fullscreen — use the matching on-screen button.

### Drum Kit instrument (9)

Select **09 Drum Kit** and every laptop key plays a drum — **36 sounds, ordered from low to high pitch** in two banks. `Z`/`X` switch banks (octave 0 = Kit, octave +1 = Percussion); the LCD shows each drum's name as you hit it.

| Key | Kit bank (octave 0) | Percussion bank (`X`) |
| --- | --- | --- |
| `A` | 808 Boom | Surdo |
| `W` | Kick | Low Conga |
| `S` | Punch Kick | High Conga |
| `E` | Floor Tom | Low Bongo |
| `D` | Low Tom | High Bongo |
| `F` | Mid Tom | Low Timbale |
| `T` | High Tom | High Timbale |
| `G` | Snare | Low Agogo |
| `Y` | Tight Snare | High Agogo |
| `H` | Clap | Low Wood Block |
| `U` | Side Stick | High Wood Block |
| `J` | Cowbell | Claves |
| `K` | Closed Hi-hat | Finger Snap |
| `O` | Pedal Hi-hat | Tambourine |
| `L` | Open Hi-hat | Shaker |
| `P` | Ride | Guiro |
| `;` | Crash | Ride Bell |
| `'` | Splash | Triangle |

On the virtual keyboard the same 36 sounds run upwards from C2 (leftmost = lowest; hover a key to see its name). MIDI export converts them to General MIDI percussion notes on channel 10. The **DRUM KIT** selector in the Rhythm panel — *Standard, Rock, Electronic 808, Dance 909, Jazz Brushes* — changes both the rhythm and the playable kit.

- Keys are matched by **physical position** (`KeyboardEvent.code`), so the layout works on QWERTY, AZERTY, QWERTZ, etc.
- Mouse/touch: click the virtual 61-key keyboard; striking nearer the front of a key is louder; drag for glissando.
- Key mappings are fully customizable in **Settings → Key mapping**.

### Rhythm & accompaniment

1. Pick a **STYLE** (8 Beat, 16 Beat, Pop Rock, Ballad, Disco, Funk, Hip-Hop, Bossa Nova, Reggae, Waltz, Jazz Swing, Slow Rock 12/8, Metronome Only).
2. Press **ACCOMP** (or `F2`), then **START** (`Enter`) — or **SYNC START** to do both.
3. Play a chord. The bass and chord parts follow it, locked to the drums.

Chord modes:
- **Fingered** — play full chords (3+ notes, any inversion). Recognizes maj, m, 7, maj7, m7, sus2/4, dim, aug, 6, m6, m7♭5, dim7, 7sus4, m(maj7), add9, 9 and power chords; the bass note resolves ambiguous shapes (C6 vs Am7). Single melody notes never change the chord.
- **Single finger (Casio-style)** — below the split point: 1 key = major, +1 lower key = minor, +2 = seventh, +3 = minor seventh. Chord-zone keys trigger the accompaniment only.
- **Manual** — choose root and type from the panel when automatic detection isn't suitable.

Transport: **START/STOP** (stop rewinds), **PAUSE** (keeps position), **RESET** (rewind + restore the style's default tempo and swing), **TAP** tempo, **SWING**, **METRO**. Style changes while playing take effect at the next bar line.

Arranger sections (every style has all of them):

| Button | Stopped | Playing |
| --- | --- | --- |
| **SYNC START** (`F5`) | Arms: the rhythm + accompaniment start with your first chord (turns ACCOMP on) | — |
| **INTRO** (`F7`) | Starts with a 2-bar intro (count-in + fill); with SYNC armed it arms the intro instead | Plays the intro from the next bar |
| **VAR A / VAR B** (`F8`/`F9`) | Selects the variation (B is busier: 16th hats, open-hat lift, crash, kick pickup) | Plays a fill-in, then switches |
| **FILL** (`F10`) | — | Fill from the current beat to the bar line (or through the next bar if the bar is almost over) |
| **ENDING** (`F11`) | — | 2-bar ending from the next bar line, final chord rings, rhythm stops by itself |

A typical song: `F5` (sync) → `F7` (intro) → play a chord → … `F10` fills between phrases … `F9` for the chorus → `F11` to finish.

### Recording

- **REC / PLAY / PAUSE / STOP / CLEAR** record what you play as events (note-on/off, sustain, instrument changes) with audio-clock timestamps, and play them back at the recorded timing.
- **SAVE** downloads the performance as JSON (format below); **LOAD** opens a file picker. **MIDI** downloads a Standard MIDI File.
- **REC AUDIO → WAV** is a *separate* feature: it captures the rendered master output (keyboard, rhythm, accompaniment, effects) and downloads a 16-bit stereo WAV (up to 10 minutes per take).

Settings are stored in each browser's `localStorage`, per laptop. The site address is part of the key, so `http://tngis.tnega.local:4008` and `http://192.168.4.252:4008` keep separate settings.

---

## Architecture

```
casio/
├─ index.html               Page shell + Content-Security-Policy
├─ deploy/
│  └─ lk61.conf             nginx site (port 4008)
└─ src/
   ├─ core/                 Pure logic — no DOM, no Web Audio
   │  ├─ event-bus.js         pub/sub
   │  ├─ note-utils.js        MIDI ⇄ frequency/name, seeded RNG
   │  ├─ key-mapping.js       default map, shortcuts, validation, KeyMapper
   │  ├─ keyboard-controller.js  key events → note/control actions (repeat-safe, no stuck notes)
   │  ├─ settings.js          schema-sanitized persistence (localStorage)
   │  ├─ sample-manifest.js   sampled-instrument manifest validation
   │  └─ platform.js          file download / file picker, app version
   ├─ audio/
   │  ├─ audio-engine.js      AudioContext, signal graph, three voice managers
   │  ├─ voice-manager.js     polyphony, voice stealing, sustain, cleanup
   │  ├─ instrument-engine.js synth patches, ADSR voices, sampled-instrument engine
   │  ├─ karplus.js           plucked-string renderer (guitar)
   │  ├─ drum-kit.js          14 synthesized drum voices + metronome click
   │  ├─ rhythm-patterns.js   style library + parser
   │  ├─ rhythm-sequencer.js  lookahead step sequencer on the audio clock
   │  ├─ chord-detector.js    fingered / single-finger / manual chords
   │  ├─ accompaniment-engine.js  bass/chord/arpeggio parts, voice leading
   │  ├─ effects-engine.js    HPF → LPF → drive → chorus → delay → reverb
   │  ├─ recording-engine.js  event recorder, file validation, player
   │  ├─ midi-exporter.js     SMF type 0 writer
   │  ├─ wav-encoder.js       16-bit PCM WAV writer
   │  ├─ audio-capture.js     rendered-audio capture (AudioWorklet, ScriptProcessor fallback)
   │  └─ worklets/capture-processor.js
   ├─ ui/                   DOM only: app.js (wiring), keyboard-view, lcd-display, panels, modal
   ├─ styles/main.css
   └─ assets/icons/app-icon.svg
```

Only `index.html` and `src/` are published to the web server.

### Signal flow

```
keyboard ┐
drums    ├─ part faders ─▶ HPF ▶ LPF ▶ Drive ▶ Chorus ▶ Delay ▶ Reverb ─▶ Master ─▶ Limiter ─▶ Analyser ─▶ Output
bass     │                                                              ▲                      └─▶ WAV capture
chord    ┘                                           metronome (dry) ───┘
```

Each effect has its own bypass with a 15 ms crossfade, so toggling never clicks.

### Timing

The rhythm sequencer, accompaniment and performance playback all use **lookahead scheduling**: a 25 ms JavaScript timer queues every event that falls inside the next 120–150 ms at an exact `AudioContext.currentTime`. Timer jitter affects only *how early* an event is queued, never *when it sounds*. UI updates (beat LEDs, playback key highlights) are queued with the same timestamps and drawn in `requestAnimationFrame`, compensated for output latency.

Keep the tab in the foreground while the rhythm plays — browsers slow down timers in background tabs.

### Voices

Every note is a small node graph (oscillators/buffer → filter → ADSR gain → panner). The voice manager enforces polyphony (default 48, stealing released voices first), holds notes under sustain, releases with an exponential fade (no clicks), and disconnects every node when the voice ends — with a timer and a periodic sweep as safety nets. Live playing, recorded playback and the accompaniment use separate voice managers so they never steal each other's sustain.

| # | Instrument | Synthesis |
| --- | --- | --- |
| 1 | Grand Piano | detuned harmonic pair, velocity-tracked filter envelope, hammer noise, pitch-dependent decay |
| 2 | Electric Piano | 2-operator FM with decaying index + tine transient |
| 3 | Drawbar Organ | additive drawbars, sub-octave, vibrato, key click |
| 4 | Saw Lead | detuned saws + sub square, resonant filter envelope |
| 5 | String Ensemble | 3 detuned saws, slow attack, delayed vibrato |
| 6 | Flute | breathy additive tone, pitch scoop, delayed vibrato |
| 7 | Plucked Guitar | Karplus–Strong string (pre-rendered asynchronously), two body resonances, pick noise |
| 8 | Electric Bass | filtered saw + sine sub, finger-pluck transient |
| 9 | Drum Kit | one-shot synthesized drums, 5 kits |
| 10 | Vibraphone | 1 : 4 : 10 bar partials, motor tremolo, mallet click |
| 11 | Brass Section | detuned saws with filter swell and pitch scoop |
| 12 | Harpsichord | bright Karplus–Strong with a 4′ octave register |
| 13 | Choir Aahs | detuned saws through "aah" formant filters, delayed vibrato |

The piano uses two layers — a bright, fast-fading attack from 2–3 detuned strings and a mellow body that rings on — so the tone darkens as it decays like a real piano. The electric piano has velocity-driven FM "bark", a second detuned carrier and tremolo; the organ has tonewheel-style percussion; the strings use five detuned players and a body resonance.

### Security

- Static site: no server-side code, no cookies, no requests to other hosts.
- Strict Content-Security-Policy in `index.html` and as an nginx header: scripts, styles and connections only from the same origin, no inline script, no framing.
- Loaded performance files are validated (format, version, event shape) before use; settings are schema-sanitized on every load and write.

---

## File formats

### Performance (`*.lk61.json`)

```json
{
  "format": "lk61-performance",
  "version": 1,
  "createdAt": "2026-10-20T10:00:00.000Z",
  "tempo": 112,
  "instrument": "piano",
  "duration": 12.5,
  "events": [
    { "t": 0,     "type": "program", "instrument": "piano" },
    { "t": 0.512, "type": "noteOn",  "note": 60, "velocity": 96 },
    { "t": 0.734, "type": "sustain", "value": true },
    { "t": 0.901, "type": "noteOff", "note": 60 }
  ]
}
```

`t` is seconds from the start. Files with a newer `version` are rejected with a clear message; malformed events are reported by index. MIDI export maps instruments to General MIDI programs and uses `tempo` for the tick grid (480 PPQ).

---

## Release checklist

Run through this on a client laptop after each deployment:

1. **Audio playback** — status pill shows *Audio ready · 48000 Hz* after the first click/key; press `A` — a piano note sounds, the C4 key lights red and the meter moves.
2. **Simultaneous notes** — hold `A D G` (C major); all three sound; `POLY` on the LCD shows 3+. Release — no notes hang. Press `Esc` while holding keys — silence.
3. **No stuck notes** — hold `A`, Alt+Tab away, come back — the note has stopped. Hold `A`, press `X` (octave up), release `A` — it stops.
4. **Sustain** — hold `Space`, tap notes, release `Space` — notes ring then fade.
5. **Rhythm sync** — select 8 Beat, `Enter`; beat dots and BAR:BEAT advance in time; change tempo with `=` while playing — no hiccup. Switch style while playing — it changes on the next bar.
6. **Accompaniment** — `F2`, `Enter`, play `A D G` — bass and e-piano follow; play `H` `K` `;` (A minor) — LCD shows *Am*.
7. **Arranger** — stop the rhythm, `F5` (SYNC lights), `F7` (INTRO lights), play `A D G` — the count-in and intro play, then VAR A; press `F9` — a fill plays and the LCD shows *VAR B*; press `F11` — the ending plays and the rhythm stops on a held chord.
8. **Drum kit** — press `9`, run your finger from `A` to `'` — drums go from deep 808 boom up to splash cymbal; press `X` and repeat for surdo → triangle; change DRUM KIT to *Electronic 808* — the kick becomes long and boomy.
9. **Recording** — `F3`, play a phrase, `F3`, `F4` — the phrase plays back with amber key highlights; SAVE (downloads), CLEAR, LOAD, PLAY again; MIDI → open the .mid in any DAW.
10. **WAV** — REC AUDIO → play with the rhythm → press again → the WAV downloads; play it in a media player.
11. **Two laptops** — open the URL on a second laptop at the same time; both play independently.

---

## Latency and performance

Typical end-to-end latency is **20–40 ms** (keyboard scan + browser event + audio buffer + OS output). Browsers cannot use ASIO or WASAPI exclusive mode, so a dedicated DAW with ASIO will be lower. Network speed does not affect latency — once the page has loaded, nothing goes over the network while playing.

To tune:
- Settings → **Latency mode**: *Lowest latency* (default) vs *Balanced*/*Most stable* if you hear crackles (applies after reloading the page). The dialog shows the measured base/output latency.
- Use wired headphones/speakers — Bluetooth adds 100–250 ms.
- Windows: set the output device to 48 kHz (matches the engine), disable “audio enhancements”, use the *Best performance* power mode on battery.
- Lower **Max polyphony** or turn off reverb on slow machines.
- Many laptop keyboards cannot register more than 3–6 simultaneous keys (“ghosting”). That's a hardware limit; the mouse and an external keyboard are not affected.

## Troubleshooting

| Problem | Fix |
| --- | --- |
| Browser can't reach `tngis.tnega.local:4008` | Try `http://192.168.4.252:4008`. If that works, fix DNS / the hosts file. If not, check `systemctl status nginx`, the firewall rule for 4008 and (RHEL) the SELinux port label. |
| Blank page | Make sure the address starts with `http://` and the server has `/var/www/lk61/src/`. Open the browser console (F12) for 404s. |
| Status pill says *Audio is paused* | Click anywhere or press a key (or the *ENABLE AUDIO* button). |
| Status pill says *No usable audio output device* | Connect/enable speakers or headphones on that laptop and reload. The UI keeps working without sound. |
| Old version after an update | Reload the page (Ctrl+F5 forces it). |
| Crackling / dropouts | Settings → Latency mode → *Balanced*, reload; close heavy tabs/apps; reduce polyphony; disable reverb. |
| Rhythm drifts or stutters | Keep the tab in the foreground; background tabs are throttled. |
| Some key combinations don't sound | Keyboard ghosting (hardware). Try chord shapes on different rows or use the mouse. |
| Notes are too quiet/loud | Velocity slider (`C`/`V`), part faders in the mixer, master volume (`[`/`]`). |
| Settings look wrong after an upgrade | Settings → *Reset all settings*. Corrupted settings are detected and reset automatically. |

## Features

- 61-key virtual keyboard, laptop + mouse/touch input, glissando, position-based velocity, key labels and laptop-zone marker
- Default and fully customizable key mapping; physical-key codes; repeat-safe, focus-loss-safe input
- Octave (±3), transpose (±12), velocity + Shift accent + humanize, sustain (hold/toggle), pitch bend, A4 tuning, master volume
- 12 synthesized instruments + playable Drum Kit, polyphony with voice stealing, ADSR, click-free release, automatic node cleanup
- 13 rhythm styles, 14 drum voices, 5 drum kits, accents/ghost notes, swing, tap tempo, metronome, start/pause/stop/reset, beat & bar display, bar-synchronized style changes
- Arranger sections for every style: intro, variation A/B, fill-in, ending, sync start
- Arranger accompaniment (bass, chord, arpeggio parts) with fingered / single-finger / manual chords and voice leading
- Mixer (5 parts) and 6 effects with independent bypass
- Event recording, playback with pause/resume, JSON save/load (versioned), MIDI export, separate WAV capture
- Settings persistence with schema validation; settings dialog; F1 shortcut reference; toasts for errors/loading

## Known limitations

- Built-in sounds are synthesized approximations, not multi-sampled acoustic recordings.
- Loading your own sampled instruments is not available in the web version (the engine support remains in `instrument-engine.js`, but there is no UI for it).
- Served over plain `http`, the page is not a "secure context", so WAV capture uses the ScriptProcessor fallback instead of an AudioWorklet. It works the same; HTTPS with a certificate the laptops trust would enable the worklet.
- Variation B, fills, intros and endings are generated from each style's main pattern by rules (styles can override them); variation B changes the drums, not the accompaniment parts.
- The accompaniment and rhythm are not included in event recordings (use WAV capture to record them).
- Performance recording is single-track.
- No Web MIDI input/output yet.
